package com.example.petstore.model;
public enum CategoryType { DOMESTIC, EXOTIC }
