package com.example.petstore.model;
public enum ProductType { TOY, FOOD }
